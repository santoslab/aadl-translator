package mdcf.app.PulseOx_Forwarding_System;

import mdcf.channelservice.common.MdcfMessage;

public class PulseOx_Logic_Process extends PulseOx_Logic_ProcessSuperType {

  public PulseOx_Logic_Process(String GUID) {
    super(GUID);
  }

  @Override
  protected void initComponent() {
    // TODO Fill in custom initialization code here
  }
  

  @Override
  protected void CheckSpO2ThreadMethod(){
    // TODO: Fill in custom periodic code here
  }
}